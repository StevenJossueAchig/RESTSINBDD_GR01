﻿using REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.controlador;

namespace REST_DOTNET_CONUNI_CLIMOV_GR01
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new NavigationPage(new LoginPage());
        }
    }
}
