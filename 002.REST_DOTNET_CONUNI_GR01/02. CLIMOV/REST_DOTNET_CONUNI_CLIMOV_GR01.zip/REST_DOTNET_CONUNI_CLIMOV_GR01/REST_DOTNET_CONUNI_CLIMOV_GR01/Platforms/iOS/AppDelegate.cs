﻿using Foundation;

namespace REST_DOTNET_CONUNI_CLIMOV_GR01
{
    [Register("AppDelegate")]
    public class AppDelegate : MauiUIApplicationDelegate
    {
        protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
    }
}
