﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.modelo
{
    public class ConUni
    {
        public double entrada { get; set; }
        public double resultado { get; set; }
        public string tipo { get; set; }
    }
}
