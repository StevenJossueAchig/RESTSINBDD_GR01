﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.modelo
{
    public class Usuario
    {
        public string usuario { get; set; }
        public string contrasena { get; set; }
    }

}
