﻿namespace REST_DOTNET_CONUNI_CLIMOV_GR01
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
