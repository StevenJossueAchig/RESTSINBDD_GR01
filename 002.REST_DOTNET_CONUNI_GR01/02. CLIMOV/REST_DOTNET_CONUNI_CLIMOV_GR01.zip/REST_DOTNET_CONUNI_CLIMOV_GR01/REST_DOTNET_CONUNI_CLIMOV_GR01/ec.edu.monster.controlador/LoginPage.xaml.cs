using REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.servicio;

namespace REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.controlador;

public partial class LoginPage : ContentPage
{
    private readonly LoginService _loginService = new();

    public LoginPage()
    {
        InitializeComponent();
    }

    private async void OnLoginClicked(object sender, EventArgs e)
    {
        mensajeLabel.IsVisible = false;
        mensajeLabel.Text = string.Empty;

        try
        {
            bool ok = await _loginService.AutenticarAsync(usuarioEntry.Text, contrasenaEntry.Text);

            if (ok)
            {
                await Navigation.PushAsync(new ConUniPage());
            }
            else
            {
                mensajeLabel.Text = "Credenciales incorrectas o no autorizadas.";
                mensajeLabel.IsVisible = true;
            }
        }
        catch (HttpRequestException ex)
        {
            mensajeLabel.Text = $"Error de conexi�n: {ex.Message}";
            mensajeLabel.IsVisible = true;
        }
        catch (Exception ex)
        {
            mensajeLabel.Text = $"Error inesperado: {ex.Message}";
            mensajeLabel.IsVisible = true;
        }
    }
}
