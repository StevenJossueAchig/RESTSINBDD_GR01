using REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.servicio;

namespace REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.controlador;

public partial class ConUniPage : ContentPage
{
    private readonly ConUniService _conUniService = new();

    public ConUniPage()
    {
        InitializeComponent();
    }

    private async void OnConvertirCmAPulgadas(object sender, EventArgs e)
    {
        if (double.TryParse(entradaValor.Text, out double valor))
        {
            var resultado = await _conUniService.ConvertirAsync(valor, "cm_a_pulgadas");
            if (resultado != null)
                etiquetaResultado.Text = $"{valor} cm = {resultado:F4} pulgadas";
            else
                etiquetaResultado.Text = "Error al convertir.";
        }
        else
        {
            etiquetaResultado.Text = "Ingrese un n�mero v�lido.";
        }
    }

    private async void OnConvertirPulgadasACm(object sender, EventArgs e)
    {
        if (double.TryParse(entradaValor.Text, out double valor))
        {
            var resultado = await _conUniService.ConvertirAsync(valor, "pulgadas_a_cm");
            if (resultado != null)
                etiquetaResultado.Text = $"{valor} pulgadas = {resultado:F4} cm";
            else
                etiquetaResultado.Text = "Error al convertir.";
        }
        else
        {
            etiquetaResultado.Text = "Ingrese un n�mero v�lido.";
        }
    }
}
