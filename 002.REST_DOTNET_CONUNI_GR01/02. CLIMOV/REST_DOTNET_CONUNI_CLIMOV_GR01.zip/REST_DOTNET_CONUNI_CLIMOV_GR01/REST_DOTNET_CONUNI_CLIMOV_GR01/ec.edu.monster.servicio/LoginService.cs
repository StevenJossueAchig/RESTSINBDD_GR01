﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.modelo;
namespace REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.servicio
{
    public class LoginService
    {
        private readonly HttpClient _http = new();
        private readonly string baseUrl = "http://192.168.1.7/ConUniRest/api/";

        public async Task<bool> AutenticarAsync(string usuario, string clave)
        {
            var data = new
            {
                Usuario = usuario,
                Clave = clave
            };

            var json = JsonSerializer.Serialize(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _http.PostAsync($"{baseUrl}login", content);

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                return false;

            if (!response.IsSuccessStatusCode)
                return false;

            // Si quieres usar el mensaje para algo:
            var respuestaJson = await response.Content.ReadAsStringAsync();
            var jsonDoc = JsonDocument.Parse(respuestaJson);
            var mensaje = jsonDoc.RootElement.GetProperty("mensaje").GetString();

            return mensaje == "Login exitoso";
        }
    }
}