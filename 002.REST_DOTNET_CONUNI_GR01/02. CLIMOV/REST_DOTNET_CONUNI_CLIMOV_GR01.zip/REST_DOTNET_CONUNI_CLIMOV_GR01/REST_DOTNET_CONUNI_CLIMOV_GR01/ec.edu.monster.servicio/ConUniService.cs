﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.modelo;

namespace REST_DOTNET_CONUNI_CLIMOV_GR01.ec.edu.monster.servicio
{
    public class ConUniService
    {
        private readonly HttpClient _http = new();
        private readonly string baseUrl = "http://192.168.1.7/ConUniRest/api/";

        public async Task<double?> ConvertirAsync(double valor, string tipo)
        {
            var data = new
            {
                Valor = valor,
                Tipo = tipo
            };

            var json = JsonSerializer.Serialize(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _http.PostAsync($"{baseUrl}conuni", content);

            if (!response.IsSuccessStatusCode)
                return null;

            var respuestaJson = await response.Content.ReadAsStringAsync();
            var jsonDoc = JsonDocument.Parse(respuestaJson);
            if (jsonDoc.RootElement.TryGetProperty("resultado", out var resultadoProp))
            {
                return resultadoProp.GetDouble();
            }

            return null;
        }
    }
}